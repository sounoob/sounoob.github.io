<?php 
include (TEMPLATEPATH . '/dynamic_sidebar.php'); 

// If you want to ignore the Theme Options handling of the sidebar and just do it yourself
// Use this one instead of the above
// include (TEMPLATEPATH . '/static_sidebar.php'); 
?>