<h2>Monthly Archives</h2>
<ul class="counts">
	<?php wp_get_archives('type=monthly&limit=12&show_post_count=1'); ?>
</ul>
