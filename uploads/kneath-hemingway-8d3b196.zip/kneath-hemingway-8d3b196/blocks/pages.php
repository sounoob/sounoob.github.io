<h2>Pages</h2>
<ul class="pages">
<?php wp_list_pages('title_li='); ?> 
</ul>
