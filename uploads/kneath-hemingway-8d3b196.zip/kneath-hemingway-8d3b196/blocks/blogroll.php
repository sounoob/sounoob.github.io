<ul class="blogroll">
	<?php wp_list_bookmarks(); ?>
</ul>
