<h2>Categories</h2>
<ul class="counts">
	<?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=0'); ?>
</ul>
