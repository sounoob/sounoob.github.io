</div><!--wrapper-->
<div class="clear"></div>
<div id="footer">
	<div id="footer-inside">
		<p>
			<?php _e('Copyright', 'zbench'); ?> &copy; <?php echo date("Y"); ?> <?php bloginfo('name'); ?>
			| Theme <a href="http://zww.me" title="designed by zwwooooo">zBench</a>
			| Powered by <a href="http://wordpress.org/">WordPress</a> 
		</p>
		<span id="back-to-top">&uarr; <a href="#" rel="nofollow" title="Back to top"><?php _e('Top', 'zbench'); ?></a></span>
	</div>
</div><!--footer-->
<?php wp_footer(); ?>
</body>
</html>